.. _optimize.minimize-trustkrylov:

minimize(method='trust-krylov')
-------------------------------------------

.. scipy-optimize:function:: scipy.optimize.minimize
   :impl: scipy.optimize._trustregion_krylov._minimize_trust_krylov
   :method: trust-krylov
