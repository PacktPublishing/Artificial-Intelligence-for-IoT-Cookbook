.. automodule:: scipy.special
