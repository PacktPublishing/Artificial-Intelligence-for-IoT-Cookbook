*********************
SciPy Developer Guide
*********************

.. include:: decisions.rst

.. include:: newfeatures.rst

.. include:: github.rst

.. include:: licensing.rst

.. include:: versioning.rst

.. include:: deprecations.rst

.. include:: distributing.rst

.. include:: releasing.rst

.. include:: modules.rst
